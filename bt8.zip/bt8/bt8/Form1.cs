﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using bt8.SchoolDB;

namespace bt8
{
    public partial class Form1 : Form
    {
        private Model1 db = new Model1();
        private BindingSource bindingSource = new BindingSource();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                LoadMajors();
                SetupDataBinding();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi kết nối database: {ex.Message}");
            }
        }

        private void LoadMajors()
        {
            cmbMajor.Items.AddRange(new string[] { "CNTT", "Kinh tế", "Kế toán", "Marketing" });
        }

        private void SetupDataBinding()
        {
            bindingSource.DataSource = db.Students.ToList();
            dataGridView1.DataSource = bindingSource;
            
            txtFullName.DataBindings.Add("Text", bindingSource, "FullName");
            txtAge.DataBindings.Add("Text", bindingSource, "Age");
            cmbMajor.DataBindings.Add("Text", bindingSource, "Major");
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtFullName.Text) || string.IsNullOrEmpty(txtAge.Text) || string.IsNullOrEmpty(cmbMajor.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                    return;
                }

                var student = new Student
                {
                    FullName = txtFullName.Text,
                    Age = int.Parse(txtAge.Text),
                    Major = cmbMajor.Text
                };

                db.Students.Add(student);
                db.SaveChanges();
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi thêm dữ liệu: {ex.Message}");
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (bindingSource.Current == null)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần xóa!");
                    return;
                }

                var student = (Student)bindingSource.Current;
                var dbStudent = db.Students.Find(student.StudentId);
                if (dbStudent != null)
                {
                    db.Students.Remove(dbStudent);
                    db.SaveChanges();
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi xóa dữ liệu: {ex.Message}");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                if (bindingSource.Current == null)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần sửa!");
                    return;
                }

                var student = (Student)bindingSource.Current;
                var dbStudent = db.Students.Find(student.StudentId);
                if (dbStudent != null)
                {
                    dbStudent.FullName = txtFullName.Text;
                    dbStudent.Age = int.Parse(txtAge.Text);
                    dbStudent.Major = cmbMajor.Text;
                    db.SaveChanges();
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi sửa dữ liệu: {ex.Message}");
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            bindingSource.MoveNext();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            bindingSource.MovePrevious();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            // Data binding tự động cập nhật, không cần xử lý thêm
        }

        private void RefreshData()
        {
            txtFullName.DataBindings.Clear();
            txtAge.DataBindings.Clear();
            cmbMajor.DataBindings.Clear();
            
            bindingSource.DataSource = db.Students.ToList();
            
            txtFullName.DataBindings.Add("Text", bindingSource, "FullName");
            txtAge.DataBindings.Add("Text", bindingSource, "Age");
            cmbMajor.DataBindings.Add("Text", bindingSource, "Major");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
