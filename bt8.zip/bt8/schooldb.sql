﻿CREATE DATABASE SchoolDB;
GO

-- Sử dụng database vừa tạo để tạo bảng
USE SchoolDB;
GO

CREATE TABLE Students (
    StudentId INT PRIMARY KEY IDENTITY(1,1), -- Khóa chính, tự động tăng
    FullName NVARCHAR(100),                 -- Họ tên (tối đa 100 ký tự)
    Age INT,                                -- Tuổi
    Major NVARCHAR(50)                      -- Chuyên ngành (tối đa 50 ký tự)
);
GO

INSERT INTO Students (FullName, Age, Major)
VALUES 
(N'Nguyễn Văn A', 20, N'Công nghệ thông tin'),
(N'Trần Thị B', 21, N'Quản trị kinh doanh'),
(N'Lê Hoàng C', 19, N'Thiết kế đồ họa'),
(N'Phạm Minh D', 22, N'Kế toán'),
(N'Vũ Phương E', 20, N'Ngôn ngữ Anh');

-- Lệnh để xem lại toàn bộ dữ liệu đã nhập
SELECT * FROM Students;